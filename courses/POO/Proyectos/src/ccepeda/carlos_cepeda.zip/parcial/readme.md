#Autor
Carlos Javier Cepeda

#Ejecicion
El programa pricipal es SistemaZamora, el cual contiene un ejemplo del
uso de las instancias de cada clase y la respectiva logica requerida en el parcial